package com.self.electronic.store.Electronicstore;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.self.electronic.store.Electronicstore.Entities.User;
import com.self.electronic.store.Electronicstore.Repository.UserREpository;
import com.self.electronic.store.Electronicstore.jwt.JwtHelper;

@SpringBootTest
class ElectronicstoreApplicationTests {

	@Autowired
	UserREpository userrepo;
	
	@Autowired
	JwtHelper jwthelper;
	@Test
	void contextLoads() {
		
		User user=userrepo.findByEmail("Ankitpandit1999@tcs.com").get();
		
		String token=jwthelper.generateToken(user);
		
		System.out.println(token); 
		}

}
