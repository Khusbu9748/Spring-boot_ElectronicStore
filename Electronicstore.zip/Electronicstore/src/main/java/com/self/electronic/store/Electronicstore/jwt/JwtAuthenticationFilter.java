package com.self.electronic.store.Electronicstore.jwt;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.self.electronic.store.Electronicstore.Service.USetAuthRepositort;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
	
	Logger logeer=LoggerFactory.getLogger(JwtAuthenticationFilter.class);
	
	@Autowired
	JwtHelper jwthelper;
	
	@Autowired
	USetAuthRepositort userdetailsService;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		//Api se phle chalega JWT header to verify the user
		
		System.out.println("request "+request);
		String requestHeader=request.getHeader("Authorization");
		
		logger.info(requestHeader);
		
		System.out.println("requestHeader "+requestHeader);
		
		String username=null;
		String token=null;
		
		if(requestHeader!=null && requestHeader.startsWith("Bearer ")) {
			//Thk hai ab process
			token=requestHeader.substring(7);
			
			try {
				
				username=jwthelper.getUserNameFromToken(token);
				logger.info("User name is  "+username);
			}
			catch(NullPointerException ex)
			{
				logger.info("Illegable argument while fetching the data");
				
			}
			catch(ExpiredJwtException exp)
			{
				logger.info("given JWT token is expire");
			}
			
			catch(MalformedJwtException expt)
			{
				logger.info("Some changes are done in token !! invalid token");
			}
			catch(Exception expty)
			{
				logger.info("no data found");
			}
		}
		else
		{
			logger.info("invalid data enter by the user");
		}
		
		System.out.println("User name "+username);
		if(username!=null && SecurityContextHolder.getContext().getAuthentication()==null)
		{

			UserDetails userDetails=userdetailsService.loadUserByUsername(username);

			//Validate token
			if(userDetails.getUsername().equalsIgnoreCase(username) && !jwthelper.isTokenExpired(token))
			{
				//Security Authentication set karenge
				UsernamePasswordAuthenticationToken authentication=new UsernamePasswordAuthenticationToken(userDetails, null);
				authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(authentication);
			}
			}
		
		filterChain.doFilter(request, response);

		}

}
