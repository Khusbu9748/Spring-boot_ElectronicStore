package com.self.electronic.store.Electronicstore.Entities;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="ES_STORE")
public class Product {
	
	@Id
	@Column(name="ES_ID")
	private String id;
	
	@Column(name="ES_NAME")
	private String name;
	
	@Column(name="ES_Image")
	private String prodImage;
	
	public String getProdImage() {
		return prodImage;
	}

	public void setProdImage(String prodImage) {
		this.prodImage = prodImage;
	}

	@Column(name="ES_ABOUT",length=1000)
	private String about;
	
	@Column(name="ES_PRICE")
	private int price;
	
	@Column(name="ES_Quantity")
	private int quantity;
	
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", about=" + about + ", price=" + price + ", quantity="
				+ quantity + ", adddedDate=" + adddedDate + ", ispresent=" + ispresent + ", stock=" + stock + ", prodImage=" + prodImage +
				", category=" + category +"]";
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(String id, String name, String about, int price, int quantity, Date adddedDate, boolean ispresent,
			boolean stock,String prodImage,Category category) {
		super();
		this.id = id;
		this.name = name;
		this.about = about;
		this.price = price;
		this.quantity = quantity;
		this.adddedDate = adddedDate;
		this.ispresent = ispresent;
		this.stock = stock;
		this.prodImage=prodImage;
		this.category=category;
		
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Date getAdddedDate() {
		return adddedDate;
	}

	public void setAdddedDate(Date adddedDate) {
		this.adddedDate = adddedDate;
	}

	public boolean isIspresent() {
		return ispresent;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public void setIspresent(boolean ispresent) {
		this.ispresent = ispresent;
	}

	public boolean isStock() {
		return stock;
	}

	public void setStock(boolean stock) {
		this.stock = stock;
	}

	@Column(name="Added_date")
	private Date adddedDate;
	
	@Column(name="is_Present")
	private boolean ispresent;
	
	@Column(name="stock")
	private boolean stock;
	
	@ManyToOne
	@JoinColumn(name="product")
	private Category category;
	
	

}
