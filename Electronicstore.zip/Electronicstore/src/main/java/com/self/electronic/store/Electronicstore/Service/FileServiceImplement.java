package com.self.electronic.store.Electronicstore.Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.UUID;

import javax.swing.JPopupMenu.Separator;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.self.electronic.store.Electronicstore.Exception.ApiBadRequestException;

import jakarta.websocket.server.ServerEndpoint;

@Service
public class FileServiceImplement implements IFileService{

	@Override
	public String uploadImage(MultipartFile file, String path) {
		// TODO Auto-generated method stub
		String originalfilename=file.getOriginalFilename();
		String filename=UUID.randomUUID().toString();
		String extention=originalfilename.substring(originalfilename.lastIndexOf("."));
		String fileNameWithExtension=filename+extention;
		String fullfilenamewithPath=path+File.separator+fileNameWithExtension;
		if(extention.equalsIgnoreCase(".png") || extention.equalsIgnoreCase(".jpg"))
		{
			File folder=new File(path);
			
			if(!folder.exists())
			{
				//create folder
				folder.mkdirs();
			}
			
			try {
				Files.copy(file.getInputStream(), Paths.get(fullfilenamewithPath));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else
		{
			 throw new ApiBadRequestException("File with "+extention+" not allowed");
		}
		return fileNameWithExtension;
	}

	@Override
	public InputStream getResource(String path, String name) {
		// TODO Auto-generated method stub
		String fullpath=path+File.separator+name;
		
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(fullpath);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return inputStream;
	}

}
