package com.self.electronic.store.Electronicstore.Dto;

import org.springframework.http.HttpStatus;

public class ApiResponseMessage {

	private String message;

	private boolean success;

	private HttpStatus status;
	
	private ApiResponseMessage(userBuilder us)
	{
		this.message=us.message;
		this.status=us.status;
		this.success=us.success;
	}


	public String getMessage() {
		return message;
	}

	

	public ApiResponseMessage() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ApiResponseMessage [message=" + message + ", success=" + success + ", status=" + status + "]";
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}


	public static class userBuilder
	{
		
		public userBuilder() {
			super();
			// TODO Auto-generated constructor stub
		}

		private String message;

		

		public userBuilder setMessage(String message) {
			this.message = message;
			return this;
		}

		

		public userBuilder setSuccess(boolean success) {
			this.success = success;
			return this;
		}

		

		public userBuilder setStatus(HttpStatus status) {
			this.status = status;
			return this;
		}

		private boolean success;

		private HttpStatus status;
		
		public userBuilder(String message,boolean success,HttpStatus status) {
			this.message = message;
			this.success = success;
			this.status = status;
			
		}
		
		public ApiResponseMessage build()
		{
			return new ApiResponseMessage(this);
		}

	}


}
