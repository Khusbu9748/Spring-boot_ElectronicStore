package com.self.electronic.store.Electronicstore.Validaton;



import org.hibernate.validator.internal.util.logging.LoggerFactory;
import org.slf4j.Logger;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class ImageNameValidator implements ConstraintValidator<ImageNameValidation,String >{

	//private Logger logger=LoggerFactory.getLogger(ImageNameValidator.class);
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		// TODO Auto-generated method stub
		
		if(value.isBlank())
		{
			
		
		return false;
		}
		else
		{
			return true;
		}
	}

}
