package com.self.electronic.store.Electronicstore.Service;

import com.self.electronic.store.Electronicstore.Dto.AddItemToCartRequest;
import com.self.electronic.store.Electronicstore.Dto.CartDto;

public interface ICartService {
	
	
	//Add item to cart
	//Case 1:Cart for user is not available :we will create a cart and then add the item
	
	//Case 2:Cart is Available Add the item to cart
	
	CartDto addItemToCart(String userId,AddItemToCartRequest request);
	
	//Remove item from cart
	
	void removeItemFromCart(String userId,int cartItem);
	
	//Clear cart
	
	void clearCart(String userId);
	
	CartDto getCartByUser(String user);
	
	
}
