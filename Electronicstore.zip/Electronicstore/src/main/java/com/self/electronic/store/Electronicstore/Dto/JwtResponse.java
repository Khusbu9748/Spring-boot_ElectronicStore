package com.self.electronic.store.Electronicstore.Dto;

public class JwtResponse {
	
	private String token;
	
	public JwtResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	private UserDto user;
	
	public JwtResponse(String token, UserDto user, String refreshToken) {
		super();
		this.token = token;
		this.user = user;
		this.refreshToken = refreshToken;
	}

	private String refreshToken;

	public UserDto getUser() {
		return user;
	}

	public void setUser(UserDto user) {
		this.user = user;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}
	
	

}
