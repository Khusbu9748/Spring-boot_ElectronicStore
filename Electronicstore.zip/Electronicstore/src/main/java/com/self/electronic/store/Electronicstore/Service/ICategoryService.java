package com.self.electronic.store.Electronicstore.Service;


import com.self.electronic.store.Electronicstore.Dto.CategoryDto;
import com.self.electronic.store.Electronicstore.Dto.PageableResponse;

public interface ICategoryService {
	
	
	public CategoryDto createCategory(CategoryDto categoryDto);
	
	public CategoryDto updateCategory(String id,CategoryDto catDto);
	
	public void deleteCategory(String id);
	
	public PageableResponse<CategoryDto> getAllData(int pageno,int pageSize,String sortby,String sortdir);
	
	public CategoryDto getSingleCategoryDto(String id);
	
	//public 

}
