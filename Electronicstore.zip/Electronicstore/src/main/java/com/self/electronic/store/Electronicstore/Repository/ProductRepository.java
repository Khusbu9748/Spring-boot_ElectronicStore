package com.self.electronic.store.Electronicstore.Repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.self.electronic.store.Electronicstore.Entities.Category;
import com.self.electronic.store.Electronicstore.Entities.Product;


public interface ProductRepository extends JpaRepository<Product, String>{

	
	Page<Product> findByCategory(Category cat,Pageable page);
}
