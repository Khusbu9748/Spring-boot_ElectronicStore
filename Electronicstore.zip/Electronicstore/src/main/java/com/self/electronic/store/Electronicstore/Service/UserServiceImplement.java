package com.self.electronic.store.Electronicstore.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import java.util.UUID;
import java.util.stream.Collectors;
import org.springframework.data.domain.Sort;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.self.electronic.store.Electronicstore.Dto.PageableResponse;
import com.self.electronic.store.Electronicstore.Dto.UserDto;
import com.self.electronic.store.Electronicstore.Entities.User;
import com.self.electronic.store.Electronicstore.Exception.ResourceNotFoundException;
import com.self.electronic.store.Electronicstore.Repository.UserREpository;
import com.self.electronic.store.Electronicstore.Utily.Helper;



@Service
public class UserServiceImplement implements IUserService{
	
	@Autowired
	UserREpository userRepo;
	
	@Autowired
	ModelMapper modelMapper;
	
	@Value("${user.profile.image.path}")
	String imagePath;

	@Override
	public UserDto createUser(UserDto user) {
		// TODO Auto-generated method stub
		
		String userId=UUID.randomUUID().toString();
		user.setUserId(userId);
		User user1=dtoToEntity(user);
		
		User savedUser=userRepo.save(user1);
		
		UserDto dto=entityToDto(savedUser);
		return dto;
	}


	private UserDto entityToDto(User user) {
		// TODO Auto-generated method stub
		
		UserDto user1=new UserDto();
		user1.setUserId(user.getUserId());
		user1.setName(user.getName());
		user1.setEmail(user.getEmail());
		user1.setGender(user.getGender());
		user1.setPassword(user.getPassword());
		user1.setAbout(user.getAbout());
		user1.setImageName(user.getImageName()); 
		
		
		
		return user1; 
	}
   

	@Override
	public UserDto updateUser(UserDto userDto, String id) {
		// TODO Auto-generated method stub
		
		User user=userRepo.findById(id).orElseThrow(()->new ResourceNotFoundException(id+" is not present in the table"));
		
		user.setName(userDto.getName());
		user.setEmail(userDto.getEmail());
		user.setGender(userDto.getGender());
		user.setPassword(userDto.getPassword());
		user.setAbout(userDto.getAbout());
		user.setImageName(userDto.getImageName());
		
		User updatedUser=userRepo.save(user);
		
		UserDto updatedDto=entityToDto(updatedUser);
		
		return updatedDto;
		
		
	}

	@Override
	public void deleteser(String userId) {
		// TODO Auto-generated method stub
		
		
		User user=userRepo.findById(userId).orElseThrow(()->new ResourceNotFoundException(userId+" is not present in the table"));
		String fullPath=imagePath+user.getImageName();
		
		Path path=Paths.get(fullPath);
		
		try {
			Files.delete(path);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		userRepo.delete(user);
		
	}

	@Override
	public PageableResponse<UserDto> getAllData(int pageNo,int pageSize,String sortby,String sortdir) {
		// TODO Auto-generated method stub
		
		//Sort sort=Sort.by(sortby);
		Sort sort=(sortdir.equalsIgnoreCase("desc")) ? (Sort.by(sortby).descending()):(Sort.by(sortby).ascending());
		Pageable pageable=PageRequest.of(pageNo, pageSize,sort);
		Page<User> page=userRepo.findAll(pageable);
		
		/*List<User> list=page.getContent();
		
		List<UserDto> updatedData=list.stream().map(user->entityToDto(user)).collect(Collectors.toList());
		PageableResponse<UserDto> pageresponse = new PageableResponse<UserDto>();
		pageresponse.setContent(updatedData);
		pageresponse.setPageNumber(page.getNumber());
		pageresponse.setPageSize(page.getSize());
		pageresponse.setTotalElement(page.getNumberOfElements());
		pageresponse.setTotalPages(page.getTotalPages());
		pageresponse.setLastPage(page.isLast()); */
		
		PageableResponse<UserDto> pageresponse=Helper.getpageleResponse(page, UserDto.class);
		return pageresponse;
	}

	@Override
	public UserDto getUserByEmail(String email) {
		// TODO Auto-generated method stub
		
		User user=userRepo.findByEmail(email).orElseThrow(()->new ResourceNotFoundException(email+" is not present in the table"));
		
		UserDto userdto=entityToDto(user);
		
		return userdto;
	}

	private User dtoToEntity(UserDto  user) {
		// TODO Auto-generated method stub
		
		User user1=new User();
		user1.setUserId(user.getUserId());
		user1.setName(user.getName());
		user1.setEmail(user.getEmail());
		user1.setGender(user.getGender());
		user1.setPassword(user.getPassword());
		user1.setAbout(user.getAbout());
		user1.setImageName(user.getImageName()); 
		
		return user1;
	}


	@Override
	public List<UserDto> searchUser(String keyword) {
		// TODO Auto-generated method stub
		List<User> user=userRepo.findByNameContaining(keyword);
		
		List<UserDto> userDto=user.stream().map(user1->entityToDto(user1)).collect(Collectors.toList());
		
		return userDto;
	}


	@Override
	public UserDto getUserById(String id) {
		// TODO Auto-generated method stub
		User user=userRepo.findById(id).orElseThrow(()->new RuntimeException(id+" is not present in the table"));
		
		return entityToDto(user);
	
	}


	
}
