package com.self.electronic.store.Electronicstore.Exception;

public class ApiBadRequestException extends RuntimeException{
	
	//private String message;
	
	public ApiBadRequestException() {
		super();
		
	}

	public ApiBadRequestException(String message) {
		super(message);
		
	}
	

}
