package com.self.electronic.store.Electronicstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.self.electronic.store.Electronicstore.Dto.ApiResponseMessage;
import com.self.electronic.store.Electronicstore.Dto.CategoryDto;
import com.self.electronic.store.Electronicstore.Dto.PageableResponse;
import com.self.electronic.store.Electronicstore.Dto.ProductDto;
import com.self.electronic.store.Electronicstore.Service.CategoryServiceImpl;
import com.self.electronic.store.Electronicstore.Service.ProductServiceImplement;

@RestController
@RequestMapping("/catergories")
public class CategoryController {
	
	@Autowired
	private CategoryServiceImpl catservice;
	
	@Autowired
	private ProductServiceImplement prodservice;
	
	
	@PostMapping("/create")
	public ResponseEntity<CategoryDto> createcetegory(@RequestBody CategoryDto catDto)
	{
		CategoryDto cat=catservice.createCategory(catDto);
		return new ResponseEntity<>(cat,HttpStatus.CREATED);
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<CategoryDto> updateCategory(@PathVariable String id,@RequestBody CategoryDto cat)
	{
		CategoryDto cate=catservice.updateCategory(id, cat);
		
		return new ResponseEntity<>(cate,HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/get")
	public ResponseEntity<PageableResponse<CategoryDto>> getAllData(@RequestParam(value="pageNo", defaultValue="0",required = false) int pageno,
			@RequestParam(value="pagesize", defaultValue="1",required = false) int pageSize,
			@RequestParam(value="sortby", defaultValue="title",required = false) String sortBy,
			@RequestParam(value="sortdir", defaultValue="desc",required = false) String sortDir)
	{
		
	PageableResponse<CategoryDto> user=catservice.getAllData(pageno,pageSize,sortBy,sortDir);
	return new ResponseEntity<>(user,HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/get/{id}")
	public ResponseEntity<CategoryDto> getCategoryById(@PathVariable String id)
	{
		CategoryDto cat=catservice.getSingleCategoryDto(id);
		
		return new ResponseEntity<>(cat,HttpStatus.ACCEPTED);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<ApiResponseMessage> deleteCat(@PathVariable String id)
	{
		catservice.deleteCategory(id);
		ApiResponseMessage apimessage=new ApiResponseMessage.userBuilder().setMessage("not Data preset to delete ")
				.setSuccess(true).setStatus(HttpStatus.BAD_REQUEST).build();
		
		return new ResponseEntity<>(apimessage,HttpStatus.BAD_REQUEST);
	}
	
	//Create category with product
	
	@PostMapping("/{id}/products")
	public ResponseEntity<ProductDto> createCategoriesWithProduct(@PathVariable String id,
			@RequestBody ProductDto prod)
	{
		ProductDto cat=prodservice.createProductWithCategory(prod, id);

         System.out.println("In controller ProductDto" +cat);
		return new ResponseEntity<>(cat,HttpStatus.OK);
	}
	
	@PutMapping("/{id}/products/{prodId}")
	public ResponseEntity<ProductDto> updateProductCategory(@PathVariable String id,@PathVariable String prodId)
	{
		ProductDto prod=prodservice.updateCategoryWithProductId(id, prodId);
		
		return new ResponseEntity<>(prod,HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/{id}/products")
	public ResponseEntity<PageableResponse<ProductDto>> updateProductCategory(@PathVariable String id,@RequestParam(value="pageNo", defaultValue="0",required = false) int pageno,
			@RequestParam(value="pagesize", defaultValue="1",required = false) int pageSize,
			@RequestParam(value="sortby", defaultValue="title",required = false) String sortBy,
			@RequestParam(value="sortdir", defaultValue="desc",required = false) String sortDir)
	{
		PageableResponse<ProductDto> prod=prodservice.getALlOfCtegory(id,pageno,pageSize,sortBy,sortDir);
		return new ResponseEntity<>(prod,HttpStatus.ACCEPTED);
	}

}
