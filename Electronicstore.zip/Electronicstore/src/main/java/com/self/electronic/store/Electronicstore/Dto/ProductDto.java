package com.self.electronic.store.Electronicstore.Dto;

import java.util.Date;

import com.self.electronic.store.Electronicstore.Entities.Category;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class ProductDto {

	
	@Override
	public String toString() {
		return "ProductDto [id=" + id + ", name=" + name + ", about=" + about + ", price=" + price + ", quantity="
				+ quantity + ", adddedDate=" + adddedDate + ", ispresent=" + ispresent + ", stock=" + stock + ", prodImage=" + prodImage + ", category=" + category +"]"; 
	}

		private String id;
		
		@NotBlank
		@Size(min = 3,max = 15,message = "Invalid length of name")
		private String name;
		
		private String about;
		
		private int price;
		
		private int quantity;
		
		private Category category;
		
		public Category getCategory() {
			return category;
		}

		public void setCategory(Category category) {
			this.category = category;
		}

		public ProductDto() {
			super();
			// TODO Auto-generated constructor stub
		}

		public ProductDto(String id, String name, String about, int price, int quantity, Date adddedDate, boolean ispresent,
				boolean stock,String prodImage,Category category) {
			super();
			this.id = id;
			this.name = name;
			this.about = about;
			this.price = price;
			this.quantity = quantity;
			this.adddedDate = adddedDate;
			this.ispresent = ispresent;
			this.stock = stock;
			this.prodImage=prodImage;
			this.category=category;;
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getAbout() {
			return about;
		}

		public void setAbout(String about) {
			this.about = about;
		}

		public int getPrice() {
			return price;
		}

		public void setPrice(int price) {
			this.price = price;
		}

		public int getQuantity() {
			return quantity;
		}

		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}

		public Date getAdddedDate() {
			return adddedDate;
		}

		public void setAdddedDate(Date adddedDate) {
			this.adddedDate = adddedDate;
		}

		public boolean isIspresent() {
			return ispresent;
		}

		public void setIspresent(boolean ispresent) {
			this.ispresent = ispresent;
		}

		public boolean isStock() {
			return stock;
		}

		public void setStock(boolean stock) {
			this.stock = stock;
		}

		private Date adddedDate;
		
		private boolean ispresent;
		
		private boolean stock;
		
		private String prodImage;

		public String getProdImage() {
			return prodImage;
		}

		public void setProdImage(String prodImage) {
			this.prodImage = prodImage;
		}
		

	}


