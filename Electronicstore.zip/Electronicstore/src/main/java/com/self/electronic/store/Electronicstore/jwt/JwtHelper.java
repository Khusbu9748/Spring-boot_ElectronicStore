package com.self.electronic.store.Electronicstore.jwt;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.self.electronic.store.Electronicstore.Entities.User;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.*;
import java.util.function.Function;




@Component
public class JwtHelper {

	//Validity in mili sec
	public static final long TOKEN_VALIDATE=5*60*60*1000;

	//Screat key generator
	public static final String secret_key="0nG4HXN83oB7xJpR2kVsZgTywqLmNpZu3eRx5sWZsUVo1kA9Tw8LqzQdPrB4YtXK";

	//Retrive usernae from the jwt token

	public String getUserNameFromToken(String token)
	{
		return getClaimsFromToken(token,Claims::getSubject);
	}

	public <T> T getClaimsFromToken(String token,Function<Claims, T> claimResolver)
	{
		final Claims claim=getAllClaimsFromToken(token);
		return claimResolver.apply(claim);
	}

	public Claims getAllClaimsFromToken(String token)
	{
		return Jwts.parser().setSigningKey(secret_key).build().parseClaimsJws(token).getPayload();
	}
	
	public  boolean isTokenExpired(String token)
	{
		final Date expire=getExpirationDateFromToken(token);
		
		return expire.before(new Date());

	}

	public Date getExpirationDateFromToken(String token) {
        return getClaimsFromToken(token, Claims::getExpiration);
    }
	
	//Generate token for user
	 public String generateToken(UserDetails email) { // Use email as username
	        Map<String, Object> claims = new HashMap<>();
	        return createToken(claims, email.getUsername());
	    }

	    private String createToken(Map<String, Object> claims, String email) {
	        return Jwts.builder()
	                .setClaims(claims)
	                .setSubject(email)
	                .setIssuedAt(new Date())
	                .setExpiration(new Date(System.currentTimeMillis() + TOKEN_VALIDATE))
	                .signWith(SignatureAlgorithm.HS256,secret_key)
	                .compact();
	        
	        
	        
	    }



}



