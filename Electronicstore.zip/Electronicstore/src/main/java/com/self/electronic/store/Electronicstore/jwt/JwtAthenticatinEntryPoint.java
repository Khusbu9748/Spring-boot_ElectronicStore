package com.self.electronic.store.Electronicstore.jwt;

import java.io.IOException;
import java.io.PrintWriter;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@Component
public class JwtAthenticatinEntryPoint implements AuthenticationEntryPoint{

	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException es) throws IOException, ServletException {
		// TODO Auto-generated method 

		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		PrintWriter ps=response.getWriter();
		ps.print("Access denies "+es.getMessage());
	}

}
