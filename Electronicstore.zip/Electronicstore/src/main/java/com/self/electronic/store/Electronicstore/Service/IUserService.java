package com.self.electronic.store.Electronicstore.Service;

import java.util.List;


import com.self.electronic.store.Electronicstore.Dto.PageableResponse;
import com.self.electronic.store.Electronicstore.Dto.UserDto;

public interface IUserService {
	
	
	//Create user
	
	UserDto createUser(UserDto user);
	
	
	//Update user
	
	UserDto updateUser(UserDto userdto,String id);
	
	//Delete user
	
	void deleteser(String userId);
	
	//Get all users
	
	PageableResponse<UserDto> getAllData(int pageNo,int pageSize,String sortby,String sortdir);
	
	//Get Single user by email
	
	UserDto getUserByEmail(String email);
	
	UserDto getUserById(String id);
	
	 List<UserDto> searchUser(String keyword);	
	//Other specific user provide here

}
