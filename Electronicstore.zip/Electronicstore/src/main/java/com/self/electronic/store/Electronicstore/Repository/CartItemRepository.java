package com.self.electronic.store.Electronicstore.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.self.electronic.store.Electronicstore.Entities.CartItem;

public interface CartItemRepository extends JpaRepository<CartItem, Integer>{

}
