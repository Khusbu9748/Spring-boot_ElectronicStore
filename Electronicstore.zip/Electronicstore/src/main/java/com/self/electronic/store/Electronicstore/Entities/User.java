package com.self.electronic.store.Electronicstore.Entities;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;



@Component
@Entity
@Table(name="ES_USER")
public class User implements UserDetails{
	
	@Override
	public String toString() {
		return "User [userId=" + userId + ", name=" + name + ", email=" + email + ", password=" + password1 + ", gender="
				+ gender + ", about=" + about + ", imageName=" + imageName + "]";
	}
	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="user_id",length=100)
	private String userId;
	@Column(name="user_name",length=100)
	private String name;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(String userId, String name, String email, String password, String gender, String about,
			String imageName) {
		super();
		this.userId = userId;
		this.name = name;
		this.email = email;
		this.password1 = password;
		this.gender = gender;
		this.about = about;
		this.imageName = imageName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword1() {
		return password1;
	}
	public void setPassword(String password) {
		this.password1 = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAbout() {
		return about;
	}
	public void setAbout(String about) {
		this.about = about;
	}
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	@Column(name="user_email",unique=true)
	private String email;
	@Column(name="user_pwd")
	private String password1;
	@Column(name="user_gnd")
	private String gender;
	@Column(name="user_about",length=100)
	private String about;
	@Column(name="user_image_name")
	private String imageName;
	
	 @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	    private List<Role> roles = new ArrayList<>();



	   // private Providers provider;


	    // important for roles.
	    public Collection<? extends GrantedAuthority> getAuthorities() {
	        Set<SimpleGrantedAuthority> authorities = roles.stream().map(role -> new SimpleGrantedAuthority(role.getName())).collect(Collectors.toSet());
	        return authorities;
	    }
	    @Override
	    public String getUsername() {
	        return this.getEmail();
	    }
		@Override
		public String getPassword() {
			// TODO Auto-generated method stub
			return this.getPassword1();
		}

	    //important
	  

}
