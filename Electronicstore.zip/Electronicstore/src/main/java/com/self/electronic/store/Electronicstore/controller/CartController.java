package com.self.electronic.store.Electronicstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.self.electronic.store.Electronicstore.Dto.AddItemToCartRequest;
import com.self.electronic.store.Electronicstore.Dto.CartDto;
import com.self.electronic.store.Electronicstore.Service.CartServiceImpl;

@RestController
@RequestMapping("/cart")
public class CartController {
	
	@Autowired
	private CartServiceImpl cartSer;
	
	
	@PostMapping("/{cartId}")
	public ResponseEntity<CartDto>  addItemToCart(@PathVariable String cartId,@RequestBody AddItemToCartRequest request)  
	{
		CartDto cartdto=cartSer.addItemToCart(cartId, request);
		
		return new ResponseEntity<>(cartdto,HttpStatus.OK);
	}
	
	@DeleteMapping("/{itemId}/item/{userId}")
	public void deleteItem(@PathVariable String userId,@PathVariable int itemId)
	{
		cartSer.removeItemFromCart(userId, itemId);
	}
	
	@DeleteMapping("/clearId")
	public void clearCart(String userId)
	{
		cartSer.clearCart(userId);
	}
	
	@GetMapping("/{userId}")
	public ResponseEntity<CartDto> getAllDataToAdd(@PathVariable String userId)
	{
		CartDto cartdto=cartSer.getCartByUser(userId);
		
		return new ResponseEntity<>(cartdto,HttpStatus.OK);
	}
	
	

}
