package com.self.electronic.store.Electronicstore.Dto;

import java.util.List;

public class PageableResponse<T> {
	
	public PageableResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	private List<T> content;
	private int pageNumber;
	private int pageSize;
	public PageableResponse(List<T> content, int pageNumber, int pageSize, long totalElement, int totalPages,
			boolean lastPage) {
		super();
		this.content = content;
		this.pageNumber = pageNumber;
		this.pageSize = pageSize;
		this.totalElement = totalElement;
		this.totalPages = totalPages;
		this.lastPage = lastPage;
	}
	public List<T> getContent() {
		return content;
	}
	public void setContent(List<T> content) {
		this.content = content;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public long getTotalElement() {
		return totalElement;
	}
	public void setTotalElement(long totalElement) {
		this.totalElement = totalElement;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public boolean isLastPage() {
		return lastPage;
	}
	public void setLastPage(boolean lastPage) {
		this.lastPage = lastPage;
	}
	@Override
	public String toString() {
		return "PageableResponse [content=" + content + ", pageNumber=" + pageNumber + ", pageSize=" + pageSize
				+ ", totalElement=" + totalElement + ", totalPages=" + totalPages + ", lastPage=" + lastPage + "]";
	}
	private long totalElement;
	private int totalPages;
	private boolean lastPage;
	

}
