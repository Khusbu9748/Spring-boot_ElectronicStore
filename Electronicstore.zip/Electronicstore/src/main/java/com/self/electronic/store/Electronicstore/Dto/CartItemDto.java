package com.self.electronic.store.Electronicstore.Dto;

import com.self.electronic.store.Electronicstore.Entities.Cart;
import com.self.electronic.store.Electronicstore.Entities.Product;

public class CartItemDto {

	private int id;


	private Product product;

	private int quantity;

	private int price;

	private Cart cart;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public CartItemDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CartItemDto(int id, Product product, int quantity, int price, Cart cart) {
		super();
		this.id = id;
		this.product = product;
		this.quantity = quantity;
		this.price = price;
		this.cart = cart;
	}

	@Override
	public String toString() {
		return "CartItemDto [id=" + id + ", product=" + product + ", quantity=" + quantity + ", price=" + price
				+ ", cart=" + cart + "]";
	}
}
