package com.self.electronic.store.Electronicstore.Utily;



import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;

import com.self.electronic.store.Electronicstore.Dto.PageableResponse;

public class Helper {
	
	
	public static <U,V> PageableResponse<V> getpageleResponse(Page<U> page,Class<V> type)
	{
		
		
		List<U> entity=page.getContent();
		
		
		List<V> updatedData=entity.stream().map(object->new ModelMapper().map(object,type)).collect(Collectors.toList());
		PageableResponse<V> pageresponse = new PageableResponse<V>();
		pageresponse.setContent(updatedData);
		pageresponse.setPageNumber(page.getNumber());
		pageresponse.setPageSize(page.getSize());
		pageresponse.setTotalElement(page.getNumberOfElements());
		pageresponse.setTotalPages(page.getTotalPages());
		pageresponse.setLastPage(page.isLast());
		
		return pageresponse;
	}

}
