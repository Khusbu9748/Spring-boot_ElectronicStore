package com.self.electronic.store.Electronicstore.Service;

import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import com.self.electronic.store.Electronicstore.Dto.AddItemToCartRequest;
import com.self.electronic.store.Electronicstore.Dto.CartDto;
import com.self.electronic.store.Electronicstore.Entities.Cart;
import com.self.electronic.store.Electronicstore.Entities.CartItem;
import com.self.electronic.store.Electronicstore.Entities.Product;
import com.self.electronic.store.Electronicstore.Entities.User;
import com.self.electronic.store.Electronicstore.Exception.ResourceNotFoundException;
import com.self.electronic.store.Electronicstore.Repository.CartItemRepository;
import com.self.electronic.store.Electronicstore.Repository.CartRepository;
import com.self.electronic.store.Electronicstore.Repository.ProductRepository;
import com.self.electronic.store.Electronicstore.Repository.UserREpository;

public class CartServiceImpl implements ICartService{


	@Autowired
	private ProductRepository prodRepo;
	@Autowired
	private UserREpository userRepo;
	@Autowired
	private CartRepository cartRepo;
	@Autowired
	private CartItemRepository cartItemRepo;
	@Autowired
	ModelMapper modelMapper;

	@Override
	public CartDto addItemToCart(String userId, AddItemToCartRequest req) {

		int quantity=req.getQuantity();
		String prodId=req.getProductId();

		if(quantity<=0)
		{
			throw new ResourceNotFoundException("REquest Quantity is not valid");
		}
		//Fetch the product
		Product prod=prodRepo.findById(prodId).orElseThrow(()->new ResourceNotFoundException("No data found"));
		//Fetch the user prod
		User user=userRepo.findById(userId).orElseThrow(()->new ResourceNotFoundException("no user found "));
		Cart cart=null;
		try
		{
			cart=cartRepo.findByUser(user).get();

		}
		catch(NoSuchElementException ex)
		{

			//Perform cart operation
			cart=new Cart();
			cart.setCartadate(new Date());

		}

		//If cart item is already present:then update

		List<CartItem>  items=cart.getItems();
		//boolean updated=false; this is not allowed in lambda functio  for that we have to use atomic reference

		AtomicReference<Boolean> updated=new AtomicReference<>(false);
		List<CartItem> updatedItem=items.stream().map(item->{
			if(item.getProduct().getId().equals(prodId))
			{
				//item already present in cart
				item.setQuantity(quantity);
				item.setPrice(quantity*prod.getPrice());
				updated.set(true);
			}
			return item;
		}).collect(Collectors.toList());

		//Create items

		if(!updated.get())
		{
			CartItem cartitem=
					CartItem.builder().quantity(quantity)
					.price(quantity*prod.getPrice())
					.cart(cart)
					.product(prod)
					.build();

			cart.getItems().add(cartitem);
			cart.setUser(user);

		}

		Cart updatedCart=cartRepo.save(cart);
		cart.setItems(updatedItem);

		return modelMapper.map(updatedCart, CartDto.class);
	}

	@Override
	public void removeItemFromCart(String userId, int cartItem) {
		// TODO Auto-generated method stub

		CartItem cartItem1=cartItemRepo.findById(cartItem).orElseThrow();

		cartItemRepo.delete(cartItem1);

	}

	@Override
	public void clearCart(String userId) {
		// TODO Auto-generated method stub

		User user=userRepo.findById(userId).orElseThrow(()->new ResourceNotFoundException("No user is present to clear the cart"));

		Cart cart=cartRepo.findByUser(user).orElseThrow(()->new ResourceNotFoundException("No user found for clear the cart"));
		cart.getItems().clear();
		cartRepo.save(cart);


	}

	@Override
	public CartDto getCartByUser(String userId) {
		// TODO Auto-generated method stub

		User user=userRepo.findById(userId).orElseThrow(()->new ResourceNotFoundException("No user is present to clear the cart"));

		Cart cart=cartRepo.findByUser(user).orElseThrow(()->new ResourceNotFoundException("No user found for clear the cart"));

		return modelMapper.map(cart, CartDto.class);
	}

}
