package com.self.electronic.store.Electronicstore.Service;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.self.electronic.store.Electronicstore.Dto.CategoryDto;
import com.self.electronic.store.Electronicstore.Dto.PageableResponse;
import com.self.electronic.store.Electronicstore.Entities.Category;
import com.self.electronic.store.Electronicstore.Exception.ResourceNotFoundException;
import com.self.electronic.store.Electronicstore.Repository.CategoryRepository;
import com.self.electronic.store.Electronicstore.Utily.Helper;

@Service
public class CategoryServiceImpl implements ICategoryService{

	@Autowired
	CategoryRepository catRepo;
	@Override
	public CategoryDto createCategory(CategoryDto categoryDto) {
		// TODO Auto-generated method stub
		
		String id=UUID.randomUUID().toString();
		categoryDto.setId(id);
		Category cat=dtoToEntity(categoryDto);
		
		Category creaCategory=catRepo.save(cat);
		
		CategoryDto updcat=entityToDto(creaCategory);
		
		return updcat;
	}

	@Override
	public CategoryDto updateCategory(String id, CategoryDto catDto) {
		// TODO Auto-generated method stub
		
		Category cat=catRepo.findById(id).orElseThrow(()->new ResourceNotFoundException(id+ "No data found for this id"));
		
		cat.setTitle(catDto.getTitle());
		Category updatedcat=catRepo.save(cat);
		
		
		return entityToDto(updatedcat);
	}

	@Override
	public void deleteCategory(String id) {
		// TODO Auto-generated method stub
		
		Category cat=catRepo.findById(id).orElseThrow(()->new ResourceNotFoundException(id+ "No data found for this id"));
		
		catRepo.delete(cat);
		
	}

	@Override
	public PageableResponse<CategoryDto> getAllData(int pageNo,int pageSize,String sortby,String sortdir) {
		// TODO Auto-generated method stub
		Sort sort=(sortdir.equalsIgnoreCase("desc")) ? (Sort.by(sortby).descending()):(Sort.by(sortby).ascending());
		Pageable pageable=PageRequest.of(pageNo, pageSize,sort);
		Page<Category> page=catRepo.findAll(pageable);
		//List<Category> cate=catRepo.findAll();
		
		PageableResponse<CategoryDto> pageresponse=Helper.getpageleResponse(page, CategoryDto.class);
		
		return pageresponse;
	}

	@Override
	public CategoryDto getSingleCategoryDto(String id) {
		// TODO Auto-generated method stub
		
		Category cat=catRepo.findById(id).orElseThrow(()->new ResourceNotFoundException(id+ "No data found for this id"));
		CategoryDto catdto=entityToDto(cat);
		return catdto;
	}
	
	public static Category dtoToEntity(CategoryDto categ)
	{
		Category cat=new Category();
		cat.setId(categ.getId());
		cat.setTitle(categ.getTitle());
		cat.setDescription(categ.getDescription());
		cat.setCoverImage(categ.getCoverImage());
		
		return cat;
	}
	
	public static CategoryDto entityToDto(Category categ)
	{
		CategoryDto cat=new CategoryDto();
		cat.setId(categ.getId());
		cat.setTitle(categ.getTitle());
		cat.setDescription(categ.getDescription());
		cat.setCoverImage(categ.getCoverImage());
		
		return cat;
	}

}
