package com.self.electronic.store.Electronicstore.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.self.electronic.store.Electronicstore.Entities.Cart;
import com.self.electronic.store.Electronicstore.Entities.User;

public interface CartRepository extends JpaRepository<Cart, String>{
	
	
	Optional<Cart> findByUser(User user);
	
	

}
