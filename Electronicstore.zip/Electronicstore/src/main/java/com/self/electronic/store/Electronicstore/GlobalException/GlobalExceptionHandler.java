package com.self.electronic.store.Electronicstore.GlobalException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.self.electronic.store.Electronicstore.Dto.ApiResponseMessage;
import com.self.electronic.store.Electronicstore.Exception.ApiBadRequestException;
import com.self.electronic.store.Electronicstore.Exception.ResourceNotFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {
	

	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<ApiResponseMessage> resourceNotFoundExceptionHandler(ResourceNotFoundException message)
	{
		ApiResponseMessage apiresponse=new ApiResponseMessage.userBuilder().setMessage("Resource not found").setSuccess(true)
				.setStatus(HttpStatus.NOT_FOUND).build();
		return new ResponseEntity<>(apiresponse,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String,Object>> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex)
	{  
		List<ObjectError> allError=ex.getBindingResult().getAllErrors();
		Map<String,Object> response=new HashMap<>();
		
		allError.stream().forEach(objecterr->{
			String mess=objecterr.getDefaultMessage();
			String field=((FieldError) objecterr).getField();
			response.put(field, mess);
			
		});
		
		return new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
		
	}
	
	@ExceptionHandler(ApiBadRequestException.class)
	public ResponseEntity<ApiResponseMessage> badRequestHandler(ApiBadRequestException api)
	{
		ApiResponseMessage apiresponse=new ApiResponseMessage.userBuilder().setMessage("Invalid file extension").setSuccess(true)
				.setStatus(HttpStatus.BAD_REQUEST).build();
		
		return new ResponseEntity<>(apiresponse,HttpStatus.BAD_REQUEST);
	}

}
