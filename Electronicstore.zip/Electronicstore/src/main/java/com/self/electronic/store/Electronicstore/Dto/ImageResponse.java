package com.self.electronic.store.Electronicstore.Dto;

import org.springframework.http.HttpStatus;

public class ImageResponse {

	private String imageName;
	private String message;

	private boolean success;

	private HttpStatus status;
	
	private ImageResponse(userBuilder us)
	{
		this.imageName=us.imageName;
		this.message=us.message;
		this.status=us.status;
		this.success=us.success;
	}


	public String getMessage() {
		return message;
	}

	public String getImageName() {
		return imageName;
	}

	

	public ImageResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ApiResponseMessage [message=" + message + ", success=" + success + ", status=" + status + "]";
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}
	
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}


	public static class userBuilder
	{
		
		public userBuilder() {
			super();
			// TODO Auto-generated constructor stub
		}

		private String message;
		
		private String imageName;

		

		public userBuilder setMessage(String message) {
			this.message = message;
			return this;
		}

		

		public userBuilder setSuccess(boolean success) {
			this.success = success;
			return this;
		}

		

		public userBuilder setStatus(HttpStatus status) {
			this.status = status;
			return this;
		}
		
		public userBuilder setImageName(String imageName) {
			this.imageName = imageName;
			return this;
		}
		

		public String getImageName() {
			return imageName;
		}

		private boolean success;

		private HttpStatus status;
		
		public userBuilder(String imageName,String message,boolean success,HttpStatus status) {
			
			this.imageName = imageName;
			this.message = message;
			this.success = success;
			this.status = status;
			
		}
		
		public ImageResponse build()
		{
			return new ImageResponse(this);
		}

	}


}
