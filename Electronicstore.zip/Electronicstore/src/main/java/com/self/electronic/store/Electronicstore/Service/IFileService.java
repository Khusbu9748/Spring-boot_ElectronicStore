package com.self.electronic.store.Electronicstore.Service;

import java.io.InputStream;

import org.springframework.web.multipart.MultipartFile;

public interface IFileService {

	public String uploadImage(MultipartFile file,String path);
	
	InputStream getResource(String path,String name);
}
