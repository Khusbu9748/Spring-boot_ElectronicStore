package com.self.electronic.store.Electronicstore.Service;

import com.self.electronic.store.Electronicstore.Dto.PageableResponse;
import com.self.electronic.store.Electronicstore.Dto.ProductDto;

public interface IProductService {
	
	public ProductDto createProduct(ProductDto prodDto);
	
	public PageableResponse<ProductDto> getAllData(int pageNo,int pageSize,String sortby,String sortdir);

	public ProductDto getDataById(String id);
	
	public ProductDto updateDto(ProductDto prodDto,String id);
	
	public void deleteDto(String id);
	
	public ProductDto createProductWithCategory(ProductDto productDto,String product);
	
	public ProductDto updateCategoryWithProductId(String catId,String prodId);
	
	public PageableResponse<ProductDto> getALlOfCtegory(String categoryId,int pageNo,int pageSize,String sortBy,String sortDir );

}
