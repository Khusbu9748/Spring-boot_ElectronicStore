package com.self.electronic.store.Electronicstore.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/* RestController is the combination of responseBody and @Controller anotation Response body retturn the 
 * output in the form of xml or JSON but @Controller return the output in the form  of jsp or any view page
 * Request mappping is used to map the class or method with the url which user enter on the web server
 * 
 */

@RestController
@RequestMapping("/test")
public class HomeController {
	
	/*
	 * @GetMapping annotation used to fetch data from backEnd to from end in the form of 
	 * XML or JSON
	 */
	@GetMapping
	public String testing()
	{
		return "Welcome to elcectronics Store";
	}
	

}
