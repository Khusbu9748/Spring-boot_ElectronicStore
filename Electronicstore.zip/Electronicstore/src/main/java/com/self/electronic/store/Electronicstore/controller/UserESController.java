package com.self.electronic.store.Electronicstore.controller;

import org.springframework.http.MediaType;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.self.electronic.store.Electronicstore.Dto.ApiResponseMessage;
import com.self.electronic.store.Electronicstore.Dto.ImageResponse;
import com.self.electronic.store.Electronicstore.Dto.PageableResponse;
import com.self.electronic.store.Electronicstore.Dto.UserDto;
import com.self.electronic.store.Electronicstore.Service.FileServiceImplement;
import com.self.electronic.store.Electronicstore.Service.UserServiceImplement;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;


@RestController
@RequestMapping("/user")
public class UserESController {


	@Autowired
	UserServiceImplement userservice;

	@Autowired
	FileServiceImplement fileupload;

	@Value("${user.profile.image.path}")
	String imagePath;	

	@PostMapping("/create")
	public ResponseEntity<UserDto> createUser(@Valid @RequestBody UserDto userDto)
	{
		UserDto user=userservice.createUser(userDto);

		System.out.println("org.springframework.boot.SpringBootVersion.getVersion() "+ org.springframework.boot.SpringBootVersion.getVersion());

		return new ResponseEntity<>(user,HttpStatus.CREATED);

	}

	//update user
	@PutMapping("/update/{userId}")
	public ResponseEntity<UserDto> updateUser(@Valid @RequestBody UserDto userdto,@PathVariable String userId)
	{

		UserDto user=userservice.updateUser(userdto, userId);
		return new ResponseEntity<>(user,HttpStatus.OK);
	}

	//delete user

	@DeleteMapping("/delete/{userId}")
	public ResponseEntity<ApiResponseMessage> deleteUSer(@PathVariable("userId") String id)
	{
		userservice.deleteser(id);

		ApiResponseMessage message=new ApiResponseMessage.userBuilder().setMessage("User Deleted successfully").setSuccess(true).setStatus(HttpStatus.OK).build();
		return new ResponseEntity<>(message,HttpStatus.ACCEPTED);
	}

	//get All 

	@GetMapping("/get")
	public ResponseEntity<PageableResponse<UserDto>> getAllUser(@RequestParam(value="pageno",defaultValue="0",required = false)int pageNo,
			@RequestParam(value="pagesize",defaultValue="5",required = false)int pageSize,
			@RequestParam(value="sortBy",defaultValue="name",required = false)String sortByName,
			@RequestParam(value="sorDir",defaultValue="asc",required = false)String sortdir)
	{
		PageableResponse<UserDto> user=userservice.getAllData(pageNo,pageSize,sortByName,sortdir);

		return new ResponseEntity<>(user,HttpStatus.OK);
	}


	//Get single
	@GetMapping("/email/{email}")
	public ResponseEntity<UserDto> userByEmail(@PathVariable String  email)
	{
		UserDto user=userservice.getUserByEmail(email);

		return new ResponseEntity<>(user,HttpStatus.OK);

	}
	@GetMapping("/get/{userId}")
	public ResponseEntity<UserDto> userById(@PathVariable String userId)
	{
		UserDto user=userservice.getUserById(userId);
		System.out.println("user  "+user);
		return new ResponseEntity<>(user,HttpStatus.OK);
	}




	//search user

	@GetMapping("/search/{keyWord}")
	public ResponseEntity<List<UserDto>> searchUser( @PathVariable("keyWord") String keyword)
	{
		List<UserDto> user=userservice.searchUser(keyword);
		return new ResponseEntity<>(user,HttpStatus.OK);
	}


	//upload user image
	@PostMapping("/image/{userId}")
	public ResponseEntity<ImageResponse> uploadUserImage(@RequestParam("userImage") MultipartFile image,@RequestParam("userImage") MultipartFile file,
			@PathVariable("userId") String userid)
	{
		String imageName=fileupload.uploadImage(file, imagePath);

		UserDto user=userservice.getUserById(userid);

		user.setImageName(imageName);

		UserDto user1=userservice.updateUser(user, userid);
		ImageResponse response=new ImageResponse.userBuilder().setMessage("File Uploaded").setImageName(imageName).setSuccess(true).setStatus(HttpStatus.OK).build();

		return new ResponseEntity<>(response,HttpStatus.OK);
	}


	//serve user Image
	@GetMapping("/image/{userId}")
	public void serverUserImage(@PathVariable String userId,HttpServletResponse res) throws IOException
	{UserDto user = userservice.getUserById(userId);  // Fetch user details

    InputStream resource = fileupload.getResource(imagePath, user.getImageName()); // Get image stream

    res.setContentType(MediaType.IMAGE_JPEG_VALUE);  // Set the correct MIME type

    StreamUtils.copy(resource, res.getOutputStream()); // Write image to response
}



}
