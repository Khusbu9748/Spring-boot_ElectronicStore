package com.self.electronic.store.Electronicstore.Dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.self.electronic.store.Electronicstore.Entities.CartItem;
import com.self.electronic.store.Electronicstore.Entities.User;


public class CartDto {
	
	
	private String id;
	
	private Date cartadate;
	
	public CartDto(String id, Date cartadate, User user, List<CartItem> items) {
		super();
		this.id = id;
		this.cartadate = cartadate;
		this.user = user;
		this.items = items;
	}

	public String getId() {
		return id;
	}

	@Override
	public String toString() {
		return "CartDto [id=" + id + ", cartadate=" + cartadate + ", user=" + user + ", items=" + items + "]";
	}

	public CartDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getCartadate() {
		return cartadate;
	}

	public void setCartadate(Date cartadate) {
		this.cartadate = cartadate;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<CartItem> getItems() {
		return items;
	}

	public void setItems(List<CartItem> items) {
		this.items = items;
	}

	private User user;
	
	private List<CartItem> items=new ArrayList<>();

}
