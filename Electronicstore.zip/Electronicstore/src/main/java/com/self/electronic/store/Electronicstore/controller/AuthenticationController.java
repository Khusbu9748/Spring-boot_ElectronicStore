package com.self.electronic.store.Electronicstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.self.electronic.store.Electronicstore.Dto.JwtRequest;
import com.self.electronic.store.Electronicstore.Dto.JwtResponse;
import com.self.electronic.store.Electronicstore.Service.USetAuthRepositort;
import com.self.electronic.store.Electronicstore.jwt.JwtHelper;


@RestController
@RequestMapping("/auth")

public class AuthenticationController {
	
	@Autowired
	AuthenticationManager authenticationManager;
	
	@Autowired
	JwtHelper jwthelper;
	
	@Autowired
	USetAuthRepositort usetAuthRepositort;
	
	@PostMapping("/generate-token")
	public ResponseEntity<JwtResponse> login(@RequestBody JwtRequest jetReq)
	{
		System.out.println("insidecontoller login");
		 this.doAuthenticate(jetReq.getUserName(), jetReq.getPassword());
		 
		 UserDetails userdetail=usetAuthRepositort.loadUserByUsername(jetReq.getUserName());
		 String token=jwthelper.generateToken(userdetail);
		 System.out.println("token "+token);
		 System.out.println("Email"+jetReq.getUserName());

		return ResponseEntity.ok(null);
	}
	
	
	private void doAuthenticate(String email, String password) {

        try {
            Authentication authentications = new UsernamePasswordAuthenticationToken(email, password);
            authenticationManager.authenticate(authentications);

        } catch (BadCredentialsException ex) {
            throw new BadCredentialsException("Invalid Username and Password !!");
        }

    }

}
