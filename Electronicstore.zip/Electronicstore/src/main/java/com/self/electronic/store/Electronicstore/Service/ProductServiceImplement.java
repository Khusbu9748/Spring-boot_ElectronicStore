package com.self.electronic.store.Electronicstore.Service;


import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.self.electronic.store.Electronicstore.Dto.PageableResponse;
import com.self.electronic.store.Electronicstore.Dto.ProductDto;
import com.self.electronic.store.Electronicstore.Entities.Category;
import com.self.electronic.store.Electronicstore.Entities.Product;
import com.self.electronic.store.Electronicstore.Exception.ResourceNotFoundException;
import com.self.electronic.store.Electronicstore.Repository.CategoryRepository;
import com.self.electronic.store.Electronicstore.Repository.ProductRepository;
import com.self.electronic.store.Electronicstore.Utily.Helper;


@Service
public class ProductServiceImplement implements IProductService{
	
	
	@Autowired
	private ProductRepository prodRepo;
	
	@Autowired
	private CategoryRepository catRepo;
	
	@Value("${product.profile.image.path}")
	String imagePath;

	@Override
	public ProductDto createProduct(ProductDto prodDto) {
		// TODO Auto-generated method stub
		Product prod=new Product();
		String id=UUID.randomUUID().toString();
		prodDto.setId(id);
		
		prodDto.setAdddedDate(new Date());
		System.out.println("ProductDto "+prodDto);
		prod=dtoToEntitiy(prodDto);
		
		System.out.println("ProductDto "+prod);
		
		
		Product currprod=prodRepo.save(prod);
		
		ProductDto currentDto=entitiyToDto(currprod);
		
		return currentDto;
		
	}

	private ProductDto entitiyToDto(Product prod) {
		
		ProductDto prodDto=new ProductDto();
		prodDto.setId(prod.getId());
		prodDto.setAbout(prod.getAbout());
		prodDto.setAdddedDate(prod.getAdddedDate());
		prodDto.setId(prod.getId());
		prodDto.setIspresent(prod.isIspresent());
		prodDto.setName(prod.getName());
		prodDto.setPrice(prod.getPrice());
		prodDto.setQuantity(prod.getQuantity());
		prodDto.setStock(prod.isStock());
		prodDto.setCategory(prod.getCategory());
		
		return prodDto;
		
	}
	
private Product dtoToEntitiy(ProductDto prodDto) {
		
	
		Product prod=new Product();
		prod.setId(prodDto.getId());
		prod.setAbout(prodDto.getAbout());
		prod.setAdddedDate(prodDto.getAdddedDate());
		
		prod.setIspresent(prodDto.isIspresent());
		prod.setName(prodDto.getName());
		prod.setPrice(prodDto.getPrice());
		prod.setQuantity(prodDto.getQuantity());
		prod.setStock(prodDto.isStock());
		prod.setCategory(prodDto.getCategory());
		
		return prod;
		
	}

public PageableResponse<ProductDto> getAllData(int pageNo,int pageSize,String sortby,String sortdir) {
	// TODO Auto-generated method stub
	
	//Sort sort=Sort.by(sortby);
	Sort sort=(sortdir.equalsIgnoreCase("desc")) ? (Sort.by(sortby).descending()):(Sort.by(sortby).ascending());
	Pageable pageable=PageRequest.of(pageNo, pageSize,sort);
	Page<Product> page=prodRepo.findAll(pageable);
	
	/*List<User> list=page.getContent();
	
	List<UserDto> updatedData=list.stream().map(user->entityToDto(user)).collect(Collectors.toList());
	PageableResponse<UserDto> pageresponse = new PageableResponse<UserDto>();
	pageresponse.setContent(updatedData);
	pageresponse.setPageNumber(page.getNumber());
	pageresponse.setPageSize(page.getSize());
	pageresponse.setTotalElement(page.getNumberOfElements());
	pageresponse.setTotalPages(page.getTotalPages());
	pageresponse.setLastPage(page.isLast()); */
	
	PageableResponse<ProductDto> pageresponse=Helper.getpageleResponse(page, ProductDto.class);
	return pageresponse;
}
	@Override
	public ProductDto getDataById(String id) {
		// TODO Auto-generated method stub
		
		Product prodTo=prodRepo.findById(id).orElseThrow(()->new ResourceNotFoundException( id +" not present in the table"));
		ProductDto prod=entitiyToDto(prodTo);
		return prod;
	}

	@Override
	public ProductDto updateDto(ProductDto prodDto, String id) {
		// TODO Auto-generated method stub
		Product prod=prodRepo.findById(id).orElseThrow(()->new ResourceNotFoundException( id +" not present in the table"));
		
		prod.setName(prodDto.getName());
		prod.setAbout(prodDto.getAbout());
		prod.setQuantity(prodDto.getQuantity());
		prod.setAdddedDate(prodDto.getAdddedDate());
		prod.setStock(true);
		prod.setIspresent(false);
		
		Product update=prodRepo.save(prod);
		
		ProductDto dto=entitiyToDto(update);
		
		
		return dto;
	}

	@Override
	public void deleteDto(String id) {
		// TODO Auto-generated method stub
		
		Product prod=prodRepo.findById(id).orElseThrow(()->new ResourceNotFoundException( id +" not present in the table"));
		
		prodRepo.delete(prod);
		
	}

	@Override
	public ProductDto createProductWithCategory(ProductDto productDto, String catgoryId) {
		
		Category cat=catRepo.findById(catgoryId).orElseThrow(()->new ResourceNotFoundException(catgoryId + "is not prrsent in the table"));
		
		Product prod=dtoToEntitiy(productDto);
		String id=UUID.randomUUID().toString();
		prod.setId(id);
		
		prod.setCategory(cat);
		prod.setAdddedDate(new Date());
		System.out.println("ProductDto "+cat);
		
		System.out.println("ProductDto "+prod);
		
		
		Product currprod=prodRepo.save(prod);
		
		System.out.println("currprod"+currprod);
		
		ProductDto currentDto=entitiyToDto(currprod);
		
		
		return currentDto;
	}

	@Override
	public ProductDto updateCategoryWithProductId(String catId, String prodId) {
		// TODO Auto-generated method stub
		Category cat=catRepo.findById(catId).orElseThrow(()->new ResourceNotFoundException(prodId +"is not present n the table"));
		
		Product prod=prodRepo.findById(prodId).orElseThrow(()->new ResourceNotFoundException(prodId + " is not present in the table"));
		
		prod.setCategory(cat);
		
		Product updatedprod=prodRepo.save(prod);
		return entitiyToDto(updatedprod);
	}

	@Override
	public PageableResponse<ProductDto> getALlOfCtegory(String categoryId,int pageNo,int pageSize,String sortBy,String sortDir ) {
		// TODO Auto-generated method stub
		
		Sort sort=(sortDir.equalsIgnoreCase("desc")? (Sort.by(sortBy).descending()):Sort.by(sortBy).ascending());
		Pageable pageable=PageRequest.of(pageNo, pageSize,sort);
		Category cat=catRepo.findById(categoryId).orElseThrow(()->new ResourceNotFoundException(categoryId +"is not present n the table"));
		

		
		Page<Product> page=prodRepo.findByCategory(cat,pageable);
		return Helper.getpageleResponse(page, ProductDto.class);
	}

	
}
