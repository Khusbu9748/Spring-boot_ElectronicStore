package com.self.electronic.store.Electronicstore.controller;

import java.io.IOException;
import java.io.InputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.self.electronic.store.Electronicstore.Dto.ApiResponseMessage;
import com.self.electronic.store.Electronicstore.Dto.ImageResponse;
import com.self.electronic.store.Electronicstore.Dto.PageableResponse;
import com.self.electronic.store.Electronicstore.Dto.ProductDto;
import com.self.electronic.store.Electronicstore.Dto.UserDto;
import com.self.electronic.store.Electronicstore.Service.FileServiceImplement;
import com.self.electronic.store.Electronicstore.Service.ProductServiceImplement;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

//is a annotation of combination of @Controller +ResponseBody Annotation 
//@Controller Annotation in java class used web controller whcich used to handle web reuest in spring/Sprin mvc project
//used to map the incoming url request with the controller method or controller class 
//RequestMapping is class as well as method level annotation
@RestController
@RequestMapping("/product")  
public class ProductController {


	@Autowired
	private ProductServiceImplement prodService;
	
	@Autowired
	FileServiceImplement fileupload;

	@Value("${product.profile.image.path}")
	String imagePath;

	@PostMapping("/create")
	public ResponseEntity<ProductDto> ctreateDto(@Valid @RequestBody ProductDto prodto)
	{
		System.out.println("ProductDto "+prodto);
		ProductDto prodDto=prodService.createProduct(prodto);

		return new ResponseEntity<>(prodDto,HttpStatus.CREATED);

	}

	@PutMapping("/update/{id}")
	public ResponseEntity<ProductDto> updateProdDto(@Valid @RequestBody ProductDto prodto,@PathVariable String id)
	{
		ProductDto prodDto=prodService.updateDto(prodto,id);

		return new ResponseEntity<>(prodDto,HttpStatus.OK);

	}

	@GetMapping("/get")
	public ResponseEntity<PageableResponse<ProductDto>> getAllRpductDto(@RequestParam(value="pagesize",defaultValue = "1",required = false) int pageSize,
			@RequestParam(value="pagesize",defaultValue = "1",required = false) int pageNo,
			@RequestParam(value="sortby",defaultValue = "name",required = false) String sortBy,
			@RequestParam(value="pagesize",defaultValue = "0",required = false) String orderBy) {

		PageableResponse<ProductDto> user=prodService.getAllData(pageNo,pageSize,sortBy,orderBy);

		return new ResponseEntity<>(user,HttpStatus.OK);

	}

	@GetMapping("/get/{id}")
	public ResponseEntity<ProductDto> getDataById(String id)
	{
		ProductDto prodDto=prodService.getDataById(id);
		return new ResponseEntity<>(prodDto,HttpStatus.OK);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<ApiResponseMessage> deleteDatabyiD(@PathVariable String id)
	{
		prodService.deleteDto(id);

		ApiResponseMessage apiRespose=new ApiResponseMessage.userBuilder().setMessage(id +"is not prsent in the table")
				.setSuccess(true).setStatus(HttpStatus.BAD_REQUEST).build();

		return new ResponseEntity<>(apiRespose,HttpStatus.BAD_REQUEST);
	}


	//upload user image
	@PostMapping("/image/{userId}")
	public ResponseEntity<ImageResponse> uploadUserImage(@RequestParam("userImage") MultipartFile image,@RequestParam("userImage") MultipartFile file,
			@PathVariable("userId") String userid)
	{
		String imageName=fileupload.uploadImage(file, imagePath);

		ProductDto user=prodService.getDataById(userid);

		user.setProdImage(imageName);

		ProductDto user1=prodService.updateDto(user, userid);
		ImageResponse response=new ImageResponse.userBuilder().setMessage("File Uploaded").setImageName(imageName).setSuccess(true).setStatus(HttpStatus.OK).build();

		return new ResponseEntity<>(response,HttpStatus.OK);
	}


	//serve user Image
	@GetMapping("/image/{userId}")
	public void serverUserImage(@PathVariable String userId,HttpServletResponse res) throws IOException
	{
		ProductDto user = prodService.getDataById(userId);  // Fetch user details

	InputStream resource = fileupload.getResource(imagePath, user.getProdImage()); // Get image stream

	res.setContentType(MediaType.IMAGE_JPEG_VALUE);  // Set the correct MIME type

	StreamUtils.copy(resource, res.getOutputStream()); // Write image to response
	}





}
