package com.self.electronic.store.Electronicstore.Entities;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="CART_ITEM")
@Setter
@Getter
@Builder
public class CartItem {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	

	@OneToOne
	private Product product;
	
	private int quantity;
	
	private int price;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private Cart cart;
	
	public CartItem setProduct(Product product)
	{
		this.product = product;
        return this;
	}
	
	public CartItem setQuantity(int quantity)
	{
		this.quantity = quantity;
        return this;
	}
	
	public CartItem setPrice(int price)
	{
		this.price = price;
        return this;
	}
	
	public CartItem setPrice(Cart cart)
	{
		this.cart = cart;
        return this;
	}
	
	
	public static class cartItemBuilder
	{
		
		private int id;
		
		private Product product;
		
		private int quantity;
		
		private int price;
		
		private Cart cart;
		
		public cartItemBuilder() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		public cartItemBuilder setProduct(Product product)
		{
			this.product = product;
	        return this;
		}
		
		public cartItemBuilder setQuantity(int quantity)
		{
			this.quantity = quantity;
	        return this;
		}
		
		public cartItemBuilder setPrice(int price)
		{
			this.price = price;
	        return this;
		}
		
		public cartItemBuilder setPrice(Cart cart)
		{
			this.cart = cart;
	        return this;
		}
		
	}

}
