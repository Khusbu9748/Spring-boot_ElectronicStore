package com.self.electronic.store.Electronicstore.Entities;


import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.util.List;
import java.util.ArrayList;


@Entity
@Table(name="ES_CATEGORY")
public class Category {
	
	@Id
	@Column(name="id")
	private String id;
	
	public Category(String id, String title, String description, String coverImage) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.coverImage = coverImage;
	}

	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Category [id=" + id + ", title=" + title + ", description=" + description + ", coverImage=" + coverImage
				+ "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCoverImage() {
		return coverImage;
	}

	public void setCoverImage(String coverImage) {
		this.coverImage = coverImage;
	}

	@Column(name="catg_title")
	private String title;
	
	@Column(name="cat_desc")
	private String description;
	
	@Column(name="Cover_Image")
	private String coverImage;
	
	@OneToMany(mappedBy = "category",cascade = CascadeType.ALL ,fetch = FetchType.LAZY)
	private List<Product> product=new ArrayList<>();
	

}
