package com.self.electronic.store.Electronicstore.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.self.electronic.store.Electronicstore.Entities.User;

/*
 * Here the interface will convert to Class at the time of Running
 */
public interface UserREpository extends JpaRepository<User, String>{
	
	Optional<User> findByEmail(String email);
	
	List<User> findByNameContaining(String keywords);

}
